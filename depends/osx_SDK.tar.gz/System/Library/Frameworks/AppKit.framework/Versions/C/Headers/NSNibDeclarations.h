/*
        NSNibDeclarations.h
        Application Kit
        Copyright (c) 1996-2017, Apple Inc.
        All rights reserved.
*/

#ifndef IBOutlet
#define IBOutlet
#endif

#ifndef IBAction
#define IBAction void
#endif

#ifndef IBInspectable
#define IBInspectable
#endif

#ifndef IB_DESIGNABLE
#define IB_DESIGNABLE
#endif

