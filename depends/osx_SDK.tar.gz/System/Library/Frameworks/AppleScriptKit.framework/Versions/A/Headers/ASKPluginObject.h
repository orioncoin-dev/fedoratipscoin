/*	ASKPluginObject.h
	Copyright 1994-2003, Apple, Inc. All rights reserved.
*/

#import <Cocoa/Cocoa.h>

@interface ASKPluginObject : NSObject 

+ (void)pluginDidLoad:(NSBundle *)bundle;

@end
